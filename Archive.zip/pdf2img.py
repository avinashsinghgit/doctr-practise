from pdf2image import convert_from_path
import os

# Function to convert PDF to images
def pdf_to_images(pdf_path, poppler_path=None):
    # Extract the file name without extension
    file_name = os.path.splitext(os.path.basename(pdf_path))[0]

    # Convert PDF to a list of images (one per page)
    images = convert_from_path(pdf_path, poppler_path=poppler_path)

    # Define the output folder
    output_folder = r'source_images'

    # Create the output folder if it doesn't exist
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Save each page as an image
    for i, image in enumerate(images):
        image_filename = os.path.join(output_folder, f"{file_name}_{i + 1}.png")
        image.save(image_filename, 'PNG')
        print(f"Saved: {image_filename}")
