import torch

class PostProcessing:

    @staticmethod
    def box_cxcywh_to_xyxy(x):
        # For output bounding box post-processing
        x_c, y_c, w, h = x.unbind(-1)
        b = [(x_c - 0.5 * w), (y_c - 0.5 * h), (x_c + 0.5 * w), (y_c + 0.5 * h)]
        return torch.stack(b, dim=-1)

    @staticmethod
    def rescale_bboxes(out_bbox, size):
        img_w, img_h = size
        b = PostProcessing.box_cxcywh_to_xyxy(out_bbox)
        bb = torch.tensor([img_w, img_h, img_w, img_h], dtype=torch.float32, device=out_bbox.device)
        return b * bb

    @staticmethod
    def outputs_to_objects(outputs, img_size, id2label):
        m = outputs.logits.softmax(-1).max(-1)
        pred_labels = m.indices[0].cpu().numpy()
        pred_scores = m.values[0].cpu().numpy()
        pred_bboxes = outputs['pred_boxes'][0].cpu()
        pred_bboxes_rescaled = PostProcessing.rescale_bboxes(pred_bboxes, img_size)

        objects = [
            {
                'label': id2label[int(label)],
                'score': float(score),
                'bbox': [float(elem) for elem in bbox]
            }
            for label, score, bbox in zip(pred_labels, pred_scores, pred_bboxes_rescaled)
            if id2label[int(label)] != 'no object'
        ]
        return objects

    def __call__(self, outputs, img_size, id2label):
        return self.outputs_to_objects(outputs, img_size, id2label)
