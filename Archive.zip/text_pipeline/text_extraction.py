from PIL import Image, ImageDraw
import os
import numpy as np

# Taking the PIL image as input and gives output as PIL Image
def remove_bboxes_from_image(org_image, bbox_list):
    # Create a drawing context to fill areas
    draw = ImageDraw.Draw(org_image)
    # Iterate over each bounding box and remove (fill with white)
    for bbox in bbox_list:
        left, top, right, bottom = map(int, bbox)  # Convert bbox to integers for coordinates
        # Draw a white rectangle over the area of the bounding box
        draw.rectangle([left, top, right, bottom], fill=(255, 255, 255, 255))  # White fill
        # org_image.save(r"C:\Users\insignia\ocr\final\output\image_without_tables.jpg")
        # org_image.show()
    return org_image
    # Save the modified image


def save_cropped_text_image(textual_image, filename, ocr_output_folder_path):
    saving_cropped_text_folder_path = os.path.join(ocr_output_folder_path, filename.split('.')[0])
    if not os.path.exists(saving_cropped_text_folder_path):
        os.makedirs(saving_cropped_text_folder_path)
    saving_cropped_text_path = os.path.join(saving_cropped_text_folder_path,'cropped_text_'+filename.split('.')[0]+'.png')
    print(f"Saving the cropped text to:: {saving_cropped_text_path}")
    textual_image.save(saving_cropped_text_path)


# Currently accepts PIL image as input
def apply_text_ocr(model, image):
    img_array = np.array(image)
    result = model([img_array])
    json_response = result.export()
    return json_response


def get_text_from_json(json_response):
    if 'pages' in json_response and json_response['pages']:
        my_json = json_response['pages'][0].get('blocks', [])
        if my_json:
            txt_list = []
            print("my_json ------>", len(my_json))
            for item in my_json:
                # print("item ------>", item)
                for line in item.get('lines', []):
                    # Extract words and append to the text list
                    for word in line.get('words', []):
                        value = word.get('value', '') + ';'  # Use .get() to avoid KeyError
                        print(value)
                        txt_list.append(value)
        else:
            print(f"No blocks found on page 0 of {filename}. Skipping text extraction.")
    return txt_list


def save_text_data(model, textual_image, filename, ocr_output_folder_path):

    json_response = apply_text_ocr(model, textual_image)
    txt_list = get_text_from_json(json_response)

    saving_text_data_folder = os.path.join(ocr_output_folder_path, filename.split('.')[0])
    if not os.path.exists(saving_text_data_folder):
        os.makedirs(saving_text_data_folder)
    saving_text_data_path = os.path.join(saving_text_data_folder,filename.split('.')[0]+'_text'+'.txt')
    print(f"Saving the text data to:: {saving_text_data_path}")
    # textual_image.save(saving_text_data_path)

    try:
        with open(saving_text_data_path, "w") as file:
            for line in txt_list:
                file.write(line + "\n")
        print(f"Text successfully saved to {filename}")
    except Exception as e:
        print(f"An error occurred while saving the file: {e}")
