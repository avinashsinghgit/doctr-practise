# always run from the path :- PS C:\Users\singaia\ocr\ID_Recs_OCR\ocr_pipeline> python main.py
# reading all the pdfs in a folder
# saving the ocr ouptut in a folder
# saving the pdf's into .png format and then also loading the images as a .png format
# input: poppler path
# input: the directory contaning '.pdf' files



import os
from pdf2img import pdf_to_images  # For converting PDF to images
from transformers import AutoModelForObjectDetection  # For table-detection model
import torch
from PIL import Image
from processing.pre_processing import MaxResize  # Importing the pre_processing.py for MaxResize class
from torchvision import transforms  # For applying transformations
from processing.post_processing import PostProcessing  # Importing the post_processing.py for PostProcessing class
from table_pipeline.table_detection import table_detection_inference, get_object, objects_to_crops, save_cropped_table  # Importing the table-detection module

from text_pipeline.text_extraction import remove_bboxes_from_image, save_cropped_text_image, save_text_data

# Doctr model
from doctr.doctr.io import DocumentFile
from doctr.doctr.models import ocr_predictor


# All necessary paths
current_script_path = os.path.abspath(__file__)  # Will point to main.py
parent_directory = os.path.dirname(current_script_path)  # Will point to ocr_pipeline
print("parent_directory ----->", parent_directory)

input_pdf_folder_path = r'/Users/avinash/Desktop/ocr/source_pdf'  # Path to read PDFs and convert them into images
ocr_output_folder_path = r"/Users/avinash/Desktop/ocr/ocr_pipeline/ocr_output"  # Path where to save all the outputs
# poppler_path = "C:\\Users\\singaia\\poppler\\Library\\bin"  # Path to Poppler bin file (Optional)
images_folder_path = fr"{parent_directory}/source_images"  # Default images folder path
print(f"Reading the images from : {images_folder_path}")


## ------------- Reading PDFs and converting them into images, then saving them in .png format
for filename in os.listdir(input_pdf_folder_path):
    if filename.endswith('.pdf'):
        file_path = os.path.join(input_pdf_folder_path, filename)
        print(f"Converting: {file_path} to images")
        
        # Converting the PDF to images
        pdf_to_images(file_path, poppler_path=None)



device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Device for loading and testing the model: {device}")


# Initializing the model here so that it is loaded once and not every time when each image is loaded
table_det_model = AutoModelForObjectDetection.from_pretrained(
    "microsoft/table-transformer-detection", 
    force_download=True, 
    revision="no_timm"
)

ocr_model = ocr_predictor(det_arch='db_resnet50', reco_arch='crnn_vgg16_bn', pretrained=True)



for filename in os.listdir(images_folder_path):
    if filename.endswith('.png'):
        file_path = os.path.join(images_folder_path, filename)
        print("-----------------------------------------------------")
        print("Image: ", file_path)
        org_image = Image.open(file_path).convert("RGB")
        width, height = org_image.size
        # display(org_image.resize((int(0.6 * width), int(0.7 * height))))

        # Defining the transformation to apply on the image
        detection_transform = transforms.Compose([
            MaxResize(800),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])

        # Applying the transformations on the image
        pixel_values = detection_transform(org_image).unsqueeze(0)
        pixel_values = pixel_values.to(device)
        # print("pixel_values --", pixel_values)
        print("Shape of the image post transformation: ", pixel_values.shape)

        # ---- Calling the table-detection module
        outputs, id2label = table_detection_inference(device, pixel_values, table_det_model)
        # print(f"outputs: {outputs} \n id2label: {id2label}")
        objects = get_object(outputs, org_image, id2label)
        # print(f"objects :: {objects}")

        tokens = []
        detection_class_thresholds = {
            "table": 0.5,
            "table rotated": 0.5,
            "no object": 10
        }
        crop_padding = 30

        tables_crops, padded_bbox_list = objects_to_crops(org_image, tokens, objects, detection_class_thresholds, padding=0)
        print(f"tables_crops :: {tables_crops}")
        save_cropped_table(tables_crops, filename, ocr_output_folder_path) # saving the cropped_table

        # ---------------- Extarcting the text part after removing table
        textual_img = remove_bboxes_from_image(org_image, padded_bbox_list)
        save_cropped_text_image(textual_img, filename, ocr_output_folder_path)
        save_text_data(ocr_model, textual_image, filename, ocr_output_folder_path)


# # Loading the remaining Text-Part
# output_txt_file_path = ocr_output_folder_path  # Placeholder for text output path

# # Loading the Table-Recognition model (not implemented in this snippet)
